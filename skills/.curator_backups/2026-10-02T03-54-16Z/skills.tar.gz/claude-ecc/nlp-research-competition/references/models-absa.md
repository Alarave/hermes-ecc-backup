# Model Architecture Reference: IndoRoBERTa vs Sahabat-AI for ABSA

## IndoRoBERTa (Encoder-Only)

**Arsitektur:**
```
Input teks → Tokenizer → [CLS] + word tokens →
12 layer Transformer Encoder (bidirectional) →
hidden representation →
Classification Head (Linear) → Label output
```

**Cara kerja:**
- Bidirectional — baca kiri ↔ kanan sekaligus
- Token `[CLS]` jadi representasi seluruh kalimat
- Ditambah 1 linear layer untuk klasifikasi (aspek & sentimen)
- Bisa multi-head: Head 1 = Aspek (4 kelas), Head 2 = Sentimen (3 kelas)

**HuggingFace:**
```
indobenchmark/indobert-base-p2
flax-community/indonesian-roberta-base
```

**Kenapa cocok ABSA:**
- Bidirectional context: paham "Baterai jelek tapi harga murah" (dua aspek)
- Ringan: ~125M params, fine-tune di T4 Colab gratis
- Konvergen cepat: 3–5 epoch cukup untuk dataset kecil
- Konsisten: output deterministik, mudah di-evaluate

**Kekurangan:**
- Tidak bisa generasi teks
- Perlu data berlabel untuk fine-tuning
- Vocab terbatas pada pre-training corpus

---

## Sahabat-AI (Decoder-Only LLM)

**Arsitektur:**
```
Input prompt → Tokenizer →
Token embeddings → N layer Transformer Decoder (causal/unidirectional) →
Next token prediction → Generated text output
```

**Cara kerja:**
- Autoregressive — baca kiri → kanan saja
- Tidak pakai `[CLS]` — output berupa teks generatif
- Bisa dikasih instruksi via prompt tanpa training

**HuggingFace:**
```
mesolitica/malaysian-llama2-7b-32k-instructions
sail/Sahabat-AI-v1-7B
```

**2 strategi untuk ABSA:**

### A. Few-Shot Prompting (tanpa training)
```
Instruksi: Klasifikasikan aspek dan sentimen komentar berikut.

Contoh 1: "Charging lama banget" → Aspek: Infrastruktur, Sentimen: Negatif
Contoh 2: "Harga BYD murah sih" → Aspek: Ekonomi, Sentimen: Positif

Komentar: "Wuling sparepart susah dicari"
Jawaban:
```

### B. LoRA Fine-Tuning
```python
# Full model: ~7B params (frozen)
# LoRA adapter: ~4-16M params (trained)
# Update < 1% dari total model
lora_r = 8        # rank
lora_alpha = 32
lora_dropout = 0.1
target_modules = ["q_proj", "v_proj"]
```

**Kelebihan:**
- Zero/few-shot: langsung pakai tanpa data berlabel
- Fleksibel: ubah prompt = ubah task
- Bisa jadi weak labeler untuk data awal

**Kekurangan:**
- Besar: ~7B params, butuh GPU VRAM ≥16GB
- Lambat: autoregressive = generate token satu-satu
- Output tidak konsisten: format jawaban bisa berubah, perlu regex parser
- Hallucination risk: bisa "mengarang" aspek

---

## 4 Aspek ABSA untuk EV China Indonesia

| Aspek | Contoh Komentar |
|---|---|
| Infrastruktur & Jangkauan | "SPKLU susah", "baterai cepet habis", "range pendek" |
| Ekonomi & Finansial | "harga mahal", "depresiasi cepet", "pajak tinggi" |
| Kualitas & Durabilitas | "material bagus", "sering mogok", "perakitan rapi" |
| Purna Jual & Ekosistem | "dealer sedikit", "garansi bagus", "sparepart susah" |

**Label sentimen:** Positif / Negatif / Netral

**Pertanyaan kritis:** Single-label atau multi-label?
- Single-label: satu komentar = satu aspek (lebih mudah, cukup untuk lomba)
- Multi-label: satu komentar bisa ≥2 aspek (lebih realistis, lebih sulit)

---

## Evaluasi Standard

Distribusi sentimen sosmed **imbalanced** — wajib Macro F1, bukan Accuracy.

```python
from sklearn.metrics import classification_report
print(classification_report(y_true, y_pred, average='macro'))
# Target: Macro F1 >= 0.65
```

Tambahan untuk paper kuat:
- Confusion matrix per aspek
- Error analysis: review komentar yang salah prediksi
- Latency comparison (ms/komentar)
- Cohen's Kappa inter-annotator agreement: κ ≥ 0.61
